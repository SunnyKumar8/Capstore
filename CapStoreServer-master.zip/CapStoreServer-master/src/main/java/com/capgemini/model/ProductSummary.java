package com.capgemini.model;

public interface ProductSummary {
	String getName();
	String getBrand();
	String getQuantity();
	String getId();
	String getDescription();
	String getCost();
	}
