package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.model.Product;

public interface SimilarProductsInterface {

	public ArrayList<Product> SimilarProductsInterface();
}
