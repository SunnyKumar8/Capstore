package com.capgemini.service;

import com.capgemini.model.Merchant;
import com.capgemini.model.Product;

public class RatingImpl implements Rating {

	@Override
	public int setRatingOfProduct(int rating) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Product updateAverageRating(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Merchant updateMerchantRating(Merchant merchant) {
		// TODO Auto-generated method stub
		return null;
	}

}
