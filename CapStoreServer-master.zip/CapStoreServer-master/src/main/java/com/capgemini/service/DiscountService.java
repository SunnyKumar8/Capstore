package com.capgemini.service;

import com.capgemini.model.Cart;
import com.capgemini.model.Product;

public interface DiscountService {
	public float DicountCalculation(Product product);
}
