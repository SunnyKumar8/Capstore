package com.capgemini.service;

import com.capgemini.model.OrderDetails;

public interface DeliveryProductsService {
 
	public OrderDetails deliveringProducts(OrderDetails orderDetails);
	
}
